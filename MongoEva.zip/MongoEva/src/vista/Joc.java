package vista;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Joc extends JFrame {

	private static final long serialVersionUID = 1L;
	public JPanel contentPane;
	public JButton btnComenzarJuego;
	public JLabel lblTiempo;
	public JButton btnGuardarDatos;
	public JButton btnVerResultados;

	public List<JButton> listButtons = new ArrayList<>();
	public List<ImageIcon> iconos = new ArrayList<>();
	private List<String> cartasVolteadas = new ArrayList<>();
	private List<String> imagenesCartas;
	private int dificultad;
	private int contadorCompletadas;

	public Timer timer;
	public int segundos;
	private String tiempo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Joc frame = new Joc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Joc() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 976, 453);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		btnComenzarJuego = new JButton("Jugar");
		btnComenzarJuego.setBackground(new Color(144, 238, 144));
		btnComenzarJuego.setBounds(10, 11, 143, 23);
		contentPane.add(btnComenzarJuego);

		btnGuardarDatos = new JButton("Guardar Datos");
		btnGuardarDatos.setBounds(10, 45, 143, 23);
		contentPane.add(btnGuardarDatos);

		lblTiempo = new JLabel("00:00");
		lblTiempo.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblTiempo.setBounds(58, 142, 48, 73);
		contentPane.add(lblTiempo);

		btnVerResultados = new JButton("Ver Resultados");
		btnVerResultados.setBounds(10, 79, 143, 23);
		contentPane.add(btnVerResultados);

		JButton btnTerminarJuego = new JButton("Terminar Juego");
		btnTerminarJuego.setBounds(10, 113, 143, 23);
		contentPane.add(btnTerminarJuego);

	}

	public void iniciarContador() {
		segundos = 0;

		// Crea un Timer que se ejecutará cada 1000 milisegundos (1 segundo)
		timer = new Timer(1000, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				segundos++;
				actualizarTiempo();
			}
		});

		// Inicia el Timer
		timer.start();
	}
	
	public void detenerContador() {
    if (timer != null && timer.isRunning()) {
        timer.stop();
    }
}


	private void actualizarTiempo() {
		// Actualiza la etiqueta de tiempo con el formato deseado (00:00)
		int minutos = segundos / 60;
		int segundosRestantes = segundos % 60;
		String tiempoFormateado = String.format("%02d:%02d", minutos, segundosRestantes);
		lblTiempo.setText(tiempoFormateado);
	}

	public void crearCuadricula(List<String> images, int dif) {
		imagenesCartas = images;
		dificultad = dif;
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				int btnX = 300;
				int btnY = 35;
				int btnWidth = 75;
				int btnHeight = 75;
				int paddingX = 10; // Ajusta el espacio horizontal entre los botones
				int paddingY = 10; // Ajusta el espacio vertical entre los botones
				int rowCount = 4;
				int totalButtons = dificultad * 2;

				for (int i = 0; i < totalButtons; i++) {
					JButton btnImg = new JButton("");
					btnImg.setIcon(null);

					Image img = null;
					try {
						img = ImageIO.read(new File(images.get(i)));
					} catch (IOException exc) {
						exc.printStackTrace();
					}
					ImageIcon icono = new ImageIcon(img);
					iconos.add(icono);

					btnImg.setBounds(btnX, btnY, btnWidth, btnHeight);
					contentPane.add(btnImg);
					listButtons.add(btnImg);

					btnX += btnWidth + paddingX;
					if ((i + 1) % rowCount == 0) {
						btnX = 300; // Ajusta el valor de inicio en X para la siguiente fila
						btnY += btnHeight + paddingY;
					}
					btnImg.setVisible(true);
				}

				// Forzar un repintado
				contentPane.revalidate();
				contentPane.repaint();

				for (JButton btn : listButtons) {
					btn.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							voltearCarta(btn);
						}
					});
				}

			}
		});
	}

	private void voltearCarta(JButton carta) {
		int indice = listButtons.indexOf(carta);

		// Verificar si el índice es válido y la carta no está ya volteada
		if (indice >= 0 && indice < imagenesCartas.size()) {
			ImageIcon icono = iconos.get(indice);
			carta.setIcon(icono);

			cartasVolteadas.add(imagenesCartas.get(indice));

			// Verificar si se han volteado dos cartas
			if (cartasVolteadas.size() == 2) {
				// Comparar las dos cartas volteadas
				if (sonCartasIguales(cartasVolteadas.get(0), cartasVolteadas.get(1))) {
					// Las cartas son iguales, mantenerlas volteadas
					cartasVolteadas.clear(); // Limpiar la lista de cartas
					contadorCompletadas++; 
					contadorCompletadas++;
				} else {
					// Las cartas no son iguales, ocultarlas después de un tiempo
					Timer timer = new Timer(300, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							ocultarCartasVolteadas();
							cartasVolteadas.clear(); // Limpiar la lista de cartas volteadas
						}
					});
					timer.setRepeats(false); // Solo se ejecutará una vez
					timer.start();
				}
			}
		}
	}

	private void reiniciarBotones() {
		// Iterar sobre los botones y restablecer su estado
		for (JButton btn : listButtons) {
			btn.setIcon(null);
		}
	}

	private boolean sonCartasIguales(String carta1, String carta2) {
    if (carta1.equals(carta2)) {
        contadorCompletadas++;
        if (contadorCompletadas == dificultad) {
            // Todas las cartas han sido encontradas, realiza las acciones finales del juego
            detenerContador();  // Detiene el contador
            // Puedes mostrar un mensaje, reiniciar el juego, etc.
            System.out.println("¡Has encontrado todas las cartas! Juego terminado.");
        }
        return true;
    }
    return false;
}


	private void ocultarCartasVolteadas() {
		// Iterar sobre los botones y ocultar las cartas que estén en la lista de
		// volteadas
		for (JButton btn : listButtons) {
			int indice = listButtons.indexOf(btn);
			if (cartasVolteadas.contains(imagenesCartas.get(indice))) {
				btn.setIcon(null);
			}
		}
	}
	
	public int getDuracion() {
	    String tiempo = lblTiempo.getText();

	    // Dividir la cadena en minutos y segundos
	    String[] partes = tiempo.split(":");
	    int minutos = Integer.parseInt(partes[0]);
	    int segundos = Integer.parseInt(partes[1]);

	    // Calcular la duración total en segundos
	    int duracionEnSegundos = minutos * 60 + segundos;

	    return duracionEnSegundos;
	}

	
	public int getDificultad() {
		int dificultadReal = dificultad*2;
		return dificultadReal;
	}

}
