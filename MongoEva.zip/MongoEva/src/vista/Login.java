package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.JPasswordField;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JTextField txtUser;
	public JButton btnAcceder;
	public JLabel lblConContraseña;
	public JCheckBox checkBoxCrearCuenta;
	public JButton btnCrearCuenta;
	public JPasswordField txtConfirmarContraseña;
	public JPasswordField txtContraseña;

	/**
	 * Launch the application.
	 */
	// public static void main(String[] args) {
	// 	EventQueue.invokeLater(new Runnable() {
	// 		public void run() {
	// 			try {
	// 				Login frame = new Login();
	// 				frame.setVisible(true);
	// 			} catch (Exception e) {
	// 				e.printStackTrace();
	// 			}
	// 		}
	// 	});
	// }

	/**
	 * Create the frame.
	 */
	public Login() {
		initComponents();
	}

	public void initComponents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 497);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panelLogin = new JPanel();
		panelLogin.setBounds(10, 10, 664, 437);
		panelLogin.setToolTipText("");
		contentPane.add(panelLogin);
		panelLogin.setLayout(null);

		lblConContraseña = new JLabel("Confirmar Contraseña");
		lblConContraseña.setBounds(10, 178, 131, 14);
		panelLogin.add(lblConContraseña);
		lblConContraseña.setVisible(false);

		JLabel lblTituloLogin = new JLabel("Inicia Sesion o Registrate");
		lblTituloLogin.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTituloLogin.setBounds(10, 11, 265, 22);
		panelLogin.add(lblTituloLogin);

		txtUser = new JTextField();
		txtUser.setBounds(10, 69, 86, 20);
		panelLogin.add(txtUser);
		txtUser.setColumns(10);

		JLabel lblUser_1 = new JLabel("Usuario");
		lblUser_1.setBounds(10, 44, 46, 14);
		panelLogin.add(lblUser_1);

		checkBoxCrearCuenta = new JCheckBox("Crear cuenta nueva");
		checkBoxCrearCuenta.setBounds(10, 148, 182, 23);
		panelLogin.add(checkBoxCrearCuenta);

		btnAcceder = new JButton("Acceder");
		btnAcceder.setBounds(7, 263, 134, 23);
		panelLogin.add(btnAcceder);

		JLabel lblContraseña = new JLabel("Contraseña");
		lblContraseña.setBounds(10, 96, 86, 14);
		panelLogin.add(lblContraseña);
		
		btnCrearCuenta = new JButton("Crear Cuenta");
		btnCrearCuenta.setBounds(7, 234, 134, 23);
		panelLogin.add(btnCrearCuenta);
		
		txtConfirmarContraseña = new JPasswordField();
		txtConfirmarContraseña.setBounds(10, 203, 86, 20);
		panelLogin.add(txtConfirmarContraseña);
		txtConfirmarContraseña.setVisible(false);
		
		txtContraseña = new JPasswordField();
		txtContraseña.setBounds(10, 121, 86, 20);
		panelLogin.add(txtContraseña);
		btnCrearCuenta.setVisible(false);
	}
	public void mostrarRestoComponentes(boolean mostrar) {
		lblConContraseña.setVisible(mostrar);
		txtConfirmarContraseña.setVisible(mostrar);
		btnCrearCuenta.setVisible(mostrar);
		btnAcceder.setVisible(!mostrar);
	}
}
