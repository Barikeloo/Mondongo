package es.florida.mongodbEvaluable;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import org.bson.Document;

import vista.Joc;
import vista.Login;
import vista.Puntuacions;

public class Controlador {

	private Modelo model;
	private Login login;
	private Joc joc;
	private Puntuacions puntuacions;

	public Controlador(Modelo model, Login login, Joc joc, Puntuacions puntuacions) throws IOException {
		this.model = model;
		this.login = login;
		this.joc = joc;
		this.puntuacions = puntuacions;
		model.connectToDatabase("./JsonConexion.json");
		initEventHandlers();
	}

	public void initEventHandlers() {
		login.btnAcceder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String usuario = login.txtUser.getText();
				String Password = login.txtContraseña.getText();
				boolean loggedIn = model.ComprobarUsuario(usuario, Password);
				if (loggedIn) {
					JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso");
					model.cargarImagenes();
					login.setVisible(false);
					joc.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "Nombre de usuario o Password incorrectos");
					login.txtUser.setText("");
					login.txtContraseña.setText("");
				}
			}
		});

		login.btnCrearCuenta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String usuario = login.txtUser.getText();
				String contrasena = login.txtContraseña.getText();
				String confContrasena = login.txtConfirmarContraseña.getText();

				// Verificar si el usuario ya existe
				if (model.existeUsuario(usuario)) {
					JOptionPane.showMessageDialog(null,
							"El usuario ya existe. Por favor, elija otro nombre de usuario.");
					return; // Salir del método si el usuario ya existe
				}

				// Verificar si las contraseñas coinciden
				if (contrasena.equals(confContrasena)) {
					// Crear el nuevo usuario si las contraseñas coinciden y el usuario no existe
					boolean creado = model.crearUsuario(usuario, contrasena);

					if (creado) {
						JOptionPane.showMessageDialog(null, "Cuenta creada correctamente.");
						login.mostrarRestoComponentes(false);
						login.checkBoxCrearCuenta.setSelected(false);
						login.txtUser.setText("");
						login.txtContraseña.setText("");
						login.txtConfirmarContraseña.setText("");
					} else {
						JOptionPane.showMessageDialog(null, "Error al crear la cuenta.");
					}
				} else {
					JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden.");
				}
			}
		});

		login.checkBoxCrearCuenta.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (login.checkBoxCrearCuenta.isSelected()) {
					login.mostrarRestoComponentes(true);
					login.btnAcceder.setVisible(false);
				} else {
					login.mostrarRestoComponentes(false);
				}
			}
		});

		joc.btnComenzarJuego.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Crear un JComboBox con las opciones
				String[] opciones = { "2x4", "4x4" };
				JComboBox<String> comboBox = new JComboBox<>(opciones);

				// Crear un JLabel para mostrar el mensaje
				JLabel label = new JLabel("Seleccione la opción de juego:");

				// Crear el panel que contiene el mensaje y el JComboBox
				JPanel panel = new JPanel();
				panel.add(label);
				panel.add(comboBox);

				// Mostrar el JOptionPane con el JComboBox
				int option = JOptionPane.showOptionDialog(null, panel, "Configuración de Juego",
						JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, null, null);

				List<String> images = new ArrayList<>();
				int dificultad = 0;

				// Verificar la opción seleccionada por el usuario
				if (option == JOptionPane.OK_OPTION) {
					// Obtener la opción seleccionada del JComboBox
					String seleccion = (String) comboBox.getSelectedItem();

					// Procesar la opción seleccionada
					if ("2x4".equals(seleccion)) {
						images = model.cargarTablero(4);
						dificultad = 4;
					} else if ("4x4".equals(seleccion)) {
						images = model.cargarTablero(8);
						dificultad = 8;
					}

					joc.crearCuadricula(images, dificultad);
					joc.iniciarContador();
				}
			}
		});

		joc.btnGuardarDatos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					long timestamp = System.currentTimeMillis();
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
					String timestampFormatted = dateFormat.format(new Date(timestamp));
					model.guardarInformacionJuego(model.getUser(), joc.getDificultad(), timestampFormatted,
							joc.getDuracion());
				} catch (Exception ex) {
					ex.printStackTrace(); // Manejo básico de excepciones, puedes ajustarlo según tus necesidades.
				}
			}
		});

		joc.btnVerResultados.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Obtener la lista de registros de la base de datos
           // Crear un nuevo objeto Puntuacions y mostrar los resultados
            Puntuacions ventanaPuntuaciones = new Puntuacions();
            ventanaPuntuaciones.setVisible(true);
        }
    });

	}

	public List<String> crearCuadricula(int numCartes) {
		return model.cargarTablero(numCartes);
	}

}
