package es.florida.mongodbEvaluable;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;

import javax.imageio.ImageIO;
import org.bson.Document;

import org.json.JSONObject;

import com.mongodb.Cursor;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import java.io.ByteArrayInputStream;
import java.util.Base64;

public class Modelo {

	private MongoClient mongoClient;
	private MongoDatabase database;
	private MongoCollection<Document> usuarisCollection;
	private MongoCollection<Document> imagesCollection;
	private MongoCollection<Document> recordsCollection;
	public String usuarioLogeado;

	public void mostrarIdsDeImagenes() {
		// Obtener todos los documentos de la colección "imagesCollection"
		FindIterable<Document> iterable = imagesCollection.find();

		// Obtener un cursor para iterar sobre los documentos
		MongoCursor<Document> cursor = iterable.iterator();

		// Iterar sobre los documentos y mostrar los IDs de las imágenes
		while (cursor.hasNext()) {
			Document document = cursor.next();
			String idImagen = document.getString("id");
		}
	}

	public boolean connectToDatabase(String jsonFilePath) {
		try {
			// Lee el contenido del archivo JSON
			String jsonString = new String(Files.readAllBytes(Paths.get(jsonFilePath)), StandardCharsets.UTF_8);

			// Convierte el JSON a un objeto JSONObject
			JSONObject json = new JSONObject(jsonString);

			// Obtiene los valores del JSON
			String ip = json.getString("ip");
			int port = json.getInt("port");
			String dbName = json.getString("bd");

			// Establece la conexión a MongoDB
			mongoClient = new MongoClient(ip, port);
			database = mongoClient.getDatabase(dbName);

			// Asigna las colecciones
			usuarisCollection = database.getCollection("usuaris");
			imagesCollection = database.getCollection("imatges");
			recordsCollection = database.getCollection("records");

			return true;
		} catch (IOException e) {
			e.printStackTrace();
			// Manejar la excepción según tus necesidades
			return false; // O lanzar otra excepción, según tus necesidades
		}
	}

	public void cargarImagenes() {
		MongoCursor<Document> cursor = imagesCollection.find().iterator();
		while (cursor.hasNext()) {
			Document document = cursor.next();
			String base64String = document.getString("base64");
			byte[] btDataFile = Base64.getDecoder().decode(base64String);

			try (FileOutputStream fos = new FileOutputStream("./src/img/" + document.getString("id"))) {
				fos.write(btDataFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public boolean ComprobarUsuario(String usuario, String contrasena) {
		try {
			// Aplica SHA-256 al hash de la contraseña proporcionada
			String hashedPassword = hashSHA256(contrasena);

			// Comprueba si existe un documento con el usuario dado y el hash de la
			// contraseña dada en la colección "usuaris"
			long count = usuarisCollection
					.countDocuments(Filters.and(Filters.eq("user", usuario), Filters.eq("pass", hashedPassword)));
			usuarioLogeado = usuario;
			return count > 0; // Retorna true si el usuario y la contraseña coinciden, false en caso contrario
		} catch (Exception e) {
			e.printStackTrace();
			// Manejar la excepción según tus necesidades
			return false; // Retornar false en caso de error
		}
	}

	public boolean existeUsuario(String usuario) {
		long count = usuarisCollection.countDocuments(Filters.eq("user", usuario));
		return count > 0;
	}

	public boolean crearUsuario(String usuario, String contrasena) {
		try {
			// Aplica SHA-256 al hash de la contraseña proporcionada
			String hashedPassword = hashSHA256(contrasena);

			// Crea un nuevo documento para el nuevo usuario
			Document nuevoUsuario = new Document("user", usuario).append("pass", hashedPassword);

			// Inserta el nuevo usuario en la colección "usuaris"
			usuarisCollection.insertOne(nuevoUsuario);

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			// Manejar la excepción según tus necesidades
			return false;
		}
	}

	private String hashSHA256(String contrasena) {
		try {
			// Aplica SHA-256 al hash de la contraseña
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hashedBytes = digest.digest(contrasena.getBytes());

			// Convierte el hash a formato hexadecimal
			StringBuilder hexString = new StringBuilder();
			for (byte hashedByte : hashedBytes) {
				String hex = Integer.toHexString(0xff & hashedByte);
				if (hex.length() == 1) {
					hexString.append('0');
				}
				hexString.append(hex);
			}

			return hexString.toString();
		} catch (Exception e) {
			e.printStackTrace();
			// Manejar la excepción según tus necesidades
			return null; // Retornar null en caso de error
		}
	}

	public List<String> listarImagenes() {
		List<String> listaImagenes = new ArrayList<>();
		listaImagenes.add("src/img/key.jpg");
		listaImagenes.add("src/img/labrador-head.jpg");
		listaImagenes.add("src/img/new-born.jpg");
		listaImagenes.add("src/img/robot-golem.jpg");
		listaImagenes.add("src/img/rocket.jpg");
		listaImagenes.add("src/img/rolling-dices.jpg");
		listaImagenes.add("src/img/shambling-zombie.jpg");
		listaImagenes.add("src/img/wolf-head.jpg");

		return listaImagenes;
	}

	public List<String> cargarTablero(int numCartas) {
		LinkedList<String> listaCartas = new LinkedList<>();
		List<String> listImages = listarImagenes();

		int n = numCartas;

		List<Integer> listaNums = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			int num = (int) (Math.random() * listImages.size());
			if (!listaNums.contains(num)) {
				listaNums.add(num);
			} else {
				i--;
			}
		}

		for (int i = 0; i < listaNums.size(); i++) {
			listaCartas.add(listImages.get(listaNums.get(i)));
			listaCartas.add(listImages.get(listaNums.get(i)));
		}

		Collections.shuffle(listaCartas);

		return listaCartas;
	}

	public void guardarInformacionJuego(String usuario, int dificultad, String timestamp, int duracion) {
		try {
			// Crear un nuevo documento con la información del juego
			Document nuevoRegistro = new Document("_id", new ObjectId()).append("usuario", usuario)
					.append("dificultad", dificultad).append("timestamp", timestamp).append("duracion", duracion);

			// Insertar el nuevo registro en la colección "records"
			recordsCollection.insertOne(nuevoRegistro);
			System.out.println(nuevoRegistro);

			// Puedes imprimir un mensaje para verificar que se guardó correctamente
			System.out.println("Información del juego guardada correctamente en la base de datos.");
		} catch (Exception e) {
			e.printStackTrace();
			// Manejar la excepción según tus necesidades
		}
	}

	public String getUser() {
		return usuarioLogeado;
	}

	public List<Document> obtenerRegistros() {
		// Obtener todos los documentos de la colección "records"
		FindIterable<Document> iterable = recordsCollection.find();

		// Obtener un cursor para iterar sobre los documentos
		MongoCursor<Document> cursor = iterable.iterator();

		// Crear una lista para almacenar los registros
		List<Document> registros = new ArrayList<>();

		// Iterar sobre los documentos y agregarlos a la lista
		while (cursor.hasNext()) {
			Document document = cursor.next();
			registros.add(document);
		}

		return registros;
	}

}
